# 🤖 INSTRUCTIONS FOR REPLIT AGENT

## Task: Implement Google Shopping Dynamic Pricing System

---

## 📦 FILES TO CREATE/MODIFY:

### **File 1: Create client/src/lib/urlParams.ts**

Location: `client/src/lib/urlParams.ts`
Action: CREATE NEW FILE
Content: See attached file `urlParams.ts`

---

### **File 2: Create client/src/components/ProductPricing.tsx**

Location: `client/src/components/ProductPricing.tsx`
Action: CREATE NEW FILE
Content: See attached file `ProductPricing.tsx`

---

### **File 3: Create client/src/components/UrgencyTimer.tsx**

Location: `client/src/components/UrgencyTimer.tsx`
Action: CREATE NEW FILE
Content: See attached file `UrgencyTimer.tsx`

---

### **File 4: Update client/src/pages/ProductDetail.tsx**

Location: `client/src/pages/ProductDetail.tsx`
Action: REPLACE ENTIRE FILE
Content: See attached file `ProductDetail-COMPLETE.tsx`

NOTE: This replaces the entire file with a complete working version that includes:
- Google Shopping detection
- Dynamic pricing display
- Conditional shipping calculator
- FAQ section
- All necessary imports

---

### **File 5: Create client/src/pages/CheckoutComplete.tsx**

Location: `client/src/pages/CheckoutComplete.tsx`
Action: CREATE NEW FILE (or replace if exists)
Content: See attached file `CheckoutComplete.tsx`

---

### **File 6: Create server/email.ts**

Location: `server/email.ts`
Action: CREATE NEW FILE
Content: See attached file `email.ts`

NOTE: Requires Resend API key in environment variables.

---

### **File 7: Update server/routes.ts**

Location: `server/routes.ts`
Action: ADD CODE TO EXISTING FILE

IMPORTANT: Do NOT replace the entire file! Add this code:

**At the top (after other imports):**
```typescript
import { sendOrderConfirmationEmail, sendAdminNotificationEmail, sendBalanceDueEmail } from './email';
```

**At the bottom (before export default):**
Add the checkout routes from `routes-checkout.ts`

Alternative: If safer, create `server/routes-checkout.ts` as a separate file and import it into routes.ts

---

## 🎯 TESTING URLS:

After implementation, test these URLs:

**Regular visitor:**
```
/product/[PRODUCT_ID]
```

**Google Shopping visitor - Connecticut:**
```
/product/[PRODUCT_ID]?state=CT&price=10839
```

**Google Shopping visitor - Alabama:**
```
/product/[PRODUCT_ID]?state=AL&price=6939
```

**Google Shopping visitor - Kentucky:**
```
/product/[PRODUCT_ID]?state=KY&price=7199
```

**Confirmation page:**
```
/checkout/complete
```

NOTE: Replace [PRODUCT_ID] with actual product ID from database.

---

## 🔐 ENVIRONMENT VARIABLES NEEDED:

Add to Replit Secrets:
```
RESEND_API_KEY=re_xxxxxxxxxxxxx
```

Get key from: https://resend.com

---

## 📋 SUCCESS CRITERIA:

✅ Regular visitors see base price with shipping calculator
✅ Google Shopping visitors see discounted price ($900 off)
✅ Google Shopping visitors see countdown timer
✅ Google Shopping visitors do NOT see shipping calculator
✅ State-specific pricing works for all states
✅ Confirmation page displays after checkout
✅ Emails send on checkout completion (if Resend configured)

---

## ⚠️ CRITICAL NOTES:

1. **DO NOT delete existing routes in routes.ts** - only add new ones
2. **ProductDetail.tsx is a complete replacement** - ensure it matches your current structure
3. **Test with actual product IDs** from your database
4. **Resend is optional** - email system works but needs API key to actually send

---

## 🚀 DEPLOYMENT:

After implementing:
1. Test locally with `npm run dev`
2. Verify URLs work with Google Shopping parameters
3. Commit to Git
4. Push to GitHub
5. Vercel auto-deploys
6. Test live URLs

---

## 📞 IF ISSUES:

- Check browser console (F12) for errors
- Verify all imports are correct
- Ensure file paths match exactly
- Check that sessionStorage is available
- Verify product IDs exist in database
