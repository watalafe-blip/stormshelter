Storm Shelter Virtual Tour — Interior (dimensioned) + LED light (Vite + React Three Fiber)

Run locally:
  npm install
  npm run dev

Edit dimensions:
- Open src/App.jsx
- Find DIM_FT and HATCH_IN and change values to match your drawing.

Notes:
- "Close Hatch" shows a door panel at the opening (it WILL dominate the view when you look up — that's real).
  Use the Back button or drag to look around (now supports turning around).
