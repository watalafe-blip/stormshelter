import React, { Suspense, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { Canvas, useFrame, useThree } from "@react-three/fiber";

/**
 * Storm Shelter Virtual Tour — Interior (dimensioned) + LED lighting
 *
 * Fixes requested:
 * - "Black thing in the middle": when the hatch is CLOSED, you are basically looking at the door panel.
 *   We make it light-gray steel and keep strong LED/ambient so it never turns into a black void.
 * - Allow rotating far enough to look around: allow ~180° TURN (i.e. +/- 180 from start) so you can
 *   look behind you. That's a 360° range. We clamp to 360° range (can be changed).
 * - Interior uses explicit dimensions (edit in DIM_FT below).
 *
 * Notes:
 * - No drei Html / OrbitControls to avoid eventSource/connect issues.
 */

// ─────────────────────────────────────────────────────────────────────────────
// Helpers / units
// ─────────────────────────────────────────────────────────────────────────────

const ft = (v) => v * 0.3048;
const inch = (v) => v * 0.0254;

function clamp01(x) {
  return Math.max(0, Math.min(1, x));
}
function smoothstep01(t) {
  const x = clamp01(t);
  return x * x * (3 - 2 * x);
}
function getSphericalFromCamera(cameraPos, target) {
  const v = new THREE.Vector3().subVectors(cameraPos, target);
  const spherical = new THREE.Spherical();
  spherical.setFromVector3(v);
  spherical.phi = THREE.MathUtils.clamp(spherical.phi, 0.001, Math.PI - 0.001);
  return spherical;
}
function cameraFromSpherical(target, spherical) {
  const v = new THREE.Vector3().setFromSpherical(spherical);
  return new THREE.Vector3().addVectors(target, v);
}

// ─────────────────────────────────────────────────────────────────────────────
// Label Sprite (CanvasTexture)
// ─────────────────────────────────────────────────────────────────────────────

function roundRect(ctx, x, y, width, height, radius) {
  const r = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + width, y, x + width, y + height, r);
  ctx.arcTo(x + width, y + height, x, y + height, r);
  ctx.arcTo(x, y + height, x, y, r);
  ctx.arcTo(x, y, x + width, y, r);
  ctx.closePath();
}

function createLabelTexture(text) {
  try {
    if (typeof document === "undefined") return null;
    const paddingX = 18;
    const paddingY = 10;
    const fontSize = 22;
    const fontFamily = "system-ui, -apple-system, Segoe UI, Roboto, Arial";

    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    if (!ctx) return null;

    ctx.font = `600 ${fontSize}px ${fontFamily}`;
    const metrics = ctx.measureText(text);
    const textWidth = Math.ceil(metrics.width);
    const textHeight = Math.ceil(fontSize * 1.2);

    const w = textWidth + paddingX * 2;
    const h = textHeight + paddingY * 2;

    canvas.width = w * 2;
    canvas.height = h * 2;
    ctx.scale(2, 2);

    ctx.fillStyle = "rgba(0,0,0,0.65)";
    ctx.strokeStyle = "rgba(255,255,255,0.25)";
    ctx.lineWidth = 1;
    roundRect(ctx, 0.5, 0.5, w - 1, h - 1, 12);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = "#fff";
    ctx.textBaseline = "middle";
    ctx.font = `600 ${fontSize}px ${fontFamily}`;
    ctx.fillText(text, paddingX, h / 2);

    const texture = new THREE.CanvasTexture(canvas);
    if ("colorSpace" in texture && THREE.SRGBColorSpace) texture.colorSpace = THREE.SRGBColorSpace;
    if ("encoding" in texture && THREE.sRGBEncoding) texture.encoding = THREE.sRGBEncoding;
    texture.minFilter = THREE.LinearFilter;
    texture.magFilter = THREE.LinearFilter;
    texture.needsUpdate = true;
    texture.userData = { w, h };
    return texture;
  } catch {
    return null;
  }
}

function Hotspot({ position, label, onClick }) {
  const texture = useMemo(() => createLabelTexture(label), [label]);

  const spriteScale = useMemo(() => {
    if (!texture?.userData) return [0.9, 0.28, 1];
    const { w, h } = texture.userData;
    const k = 220;
    return [Math.max(0.6, w / k), Math.max(0.22, h / k), 1];
  }, [texture]);

  return (
    <group position={position}>
      <mesh
        onClick={(e) => {
          e.stopPropagation();
          onClick?.();
        }}
        onPointerOver={(e) => {
          e.stopPropagation();
          if (typeof document !== "undefined") document.body.style.cursor = "pointer";
        }}
        onPointerOut={(e) => {
          e.stopPropagation();
          if (typeof document !== "undefined") document.body.style.cursor = "default";
        }}
      >
        <sphereGeometry args={[0.045, 18, 18]} />
        <meshStandardMaterial color="#111" emissive="#fff" emissiveIntensity={1.5} roughness={0.3} />
      </mesh>

      {texture && (
        <sprite position={[0, 0.16, 0]} scale={spriteScale} renderOrder={10}>
          <spriteMaterial map={texture} transparent depthWrite={false} toneMapped={false} />
        </sprite>
      )}
    </group>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Simple Man (scale reference) — back to camera, facing hatch
// ─────────────────────────────────────────────────────────────────────────────

function Man() {
  // More human-like proportions (still simple, but clearly a person)
  const jacketMat = useMemo(() => new THREE.MeshStandardMaterial({ color: "#1f1f1f", roughness: 0.9 }), []);
  const pantsMat = useMemo(() => new THREE.MeshStandardMaterial({ color: "#2f4b7c", roughness: 0.9 }), []);
  const skinMat = useMemo(() => new THREE.MeshStandardMaterial({ color: "#cfa37b", roughness: 0.85 }), []);
  const shoeMat = useMemo(() => new THREE.MeshStandardMaterial({ color: "#0f0f0f", roughness: 0.95 }), []);

  return (
    <group>
      {/* Torso */}
      <mesh material={jacketMat} position={[0, 1.18, 0]}>
        <capsuleGeometry args={[0.23, 0.85, 8, 18]} />
      </mesh>

      {/* Hips */}
      <mesh material={pantsMat} position={[0, 0.78, 0]}>
        <capsuleGeometry args={[0.20, 0.45, 8, 18]} />
      </mesh>

      {/* Neck */}
      <mesh material={skinMat} position={[0, 1.63, 0]}>
        <capsuleGeometry args={[0.065, 0.12, 6, 14]} />
      </mesh>

      {/* Head */}
      <mesh material={skinMat} position={[0, 1.83, 0]}>
        <sphereGeometry args={[0.16, 22, 22]} />
      </mesh>

      {/* Arms (down by sides) */}
      <mesh material={jacketMat} position={[-0.32, 1.22, 0]} rotation={[0, 0, 0.08]}>
        <capsuleGeometry args={[0.07, 0.62, 8, 16]} />
      </mesh>
      <mesh material={jacketMat} position={[0.32, 1.22, 0]} rotation={[0, 0, -0.08]}>
        <capsuleGeometry args={[0.07, 0.62, 8, 16]} />
      </mesh>

      {/* Hands */}
      <mesh material={skinMat} position={[-0.34, 0.86, 0.03]}>
        <sphereGeometry args={[0.06, 16, 16]} />
      </mesh>
      <mesh material={skinMat} position={[0.34, 0.86, 0.03]}>
        <sphereGeometry args={[0.06, 16, 16]} />
      </mesh>

      {/* Legs */}
      <mesh material={pantsMat} position={[-0.11, 0.40, 0]}>
        <capsuleGeometry args={[0.085, 0.72, 8, 16]} />
      </mesh>
      <mesh material={pantsMat} position={[0.11, 0.40, 0]}>
        <capsuleGeometry args={[0.085, 0.72, 8, 16]} />
      </mesh>

      {/* Shoes */}
      <mesh material={shoeMat} position={[-0.11, 0.04, 0.06]}>
        <boxGeometry args={[0.14, 0.08, 0.28]} />
      </mesh>
      <mesh material={shoeMat} position={[0.11, 0.04, 0.06]}>
        <boxGeometry args={[0.14, 0.08, 0.28]} />
      </mesh>
    </group>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Dimensioned interior model + hatch + LED

// ─────────────────────────────────────────────────────────────────────────────

/**
 * Edit these to match YOUR drawing.
 * (I can’t read exact numbers from the diagram image; it shows details not full dimensions.)
 * Defaults below are a common “small shelter” interior in feet.
 */
const DIM_FT = {
  width: 4.5,   // interior clear width
  length: 8.0,  // interior clear length
  height: 6.5,  // interior clear height
};

// Door (hatch) size
const HATCH_IN = { width: 32, height: 48, thickness: 2.0 }; // inches

// Tuning: move man further back toward the rear wall (+Z)
const MAN_BACK_FT = 1.5; // feet (increase to step back more)

function SimpleShelter({ hatchClosed, ghostWalls }) {
  const W = ft(DIM_FT.width);
  const L = ft(DIM_FT.length);
  const H = ft(DIM_FT.height);

  // Materials: keep “not black”
  const concrete = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: "#cdcdcd",
        roughness: 0.98,
        metalness: 0.0,
        side: THREE.DoubleSide,
        transparent: ghostWalls,
        opacity: ghostWalls ? 0.28 : 1.0,
        depthWrite: !ghostWalls,
      }),
    [ghostWalls]
  );

  const steel = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: "#9a9a9a", // lighter steel so it doesn't go black
        roughness: 0.35,
        metalness: 0.5,
        side: THREE.DoubleSide,
      }),
    []
  );

  const darkSteel = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: "#4f4f4f",
        roughness: 0.5,
        metalness: 0.45,
        side: THREE.DoubleSide,
      }),
    []
  );

  const ledMat = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: "#f7f7f7",
        emissive: new THREE.Color("#ffffff"),
        emissiveIntensity: 4.0,
        roughness: 0.2,
        metalness: 0.0,
      }),
    []
  );

  const outsideMat = useMemo(
    () => new THREE.MeshBasicMaterial({ color: "#efefef", side: THREE.DoubleSide }),
    []
  );

  const wallAngle = 0.18;

  // Opening at -Z
  const openingZ = -L / 2;

  // Stairs (fit to height)
  const landingZ = L / 2 - ft(1.25); // bottom landing towards +Z
  const stairTopZ = openingZ + ft(1.2); // top near hatch
  const runTotal = landingZ - stairTopZ;

  const stepCount = 9;
  const stepRise = (H - ft(1.2)) / stepCount; // reach near hatch level
  const stepRun = runTotal / stepCount;

  const stairStartY = ft(0.25);
  const stairStartZ = landingZ - ft(2.2); // moved forward to give man ~arm-length clearance before first step

  const railX = W / 2 - ft(0.35);

  // Hatch panel
  const hatchW = inch(HATCH_IN.width);
  const hatchH = inch(HATCH_IN.height);
  const hatchT = inch(HATCH_IN.thickness);
  const hatchY = H - ft(0.25);

  // LED fixture near ceiling
  const ledY = H - ft(0.55);

  return (
    <group>
      {/* Floor */}
      <mesh material={concrete} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]}>
        <planeGeometry args={[W + ft(2.0), L + ft(2.0)]} />
      </mesh>

      {/* End wall at +Z */}
      <mesh material={concrete} position={[0, H / 2, L / 2]} rotation={[0, Math.PI, 0]}>
        <planeGeometry args={[W + ft(2.0), H]} />
      </mesh>

      {/* Side walls (tilt inward a bit) */}
      <mesh material={concrete} position={[-W / 2, H / 2, 0]} rotation={[0, Math.PI / 2 + wallAngle, 0]}>
        <planeGeometry args={[L + ft(2.0), H]} />
      </mesh>
      <mesh material={concrete} position={[W / 2, H / 2, 0]} rotation={[0, -Math.PI / 2 - wallAngle, 0]}>
        <planeGeometry args={[L + ft(2.0), H]} />
      </mesh>

      {/* Header/lip at opening */}
      <mesh material={concrete} position={[0, H - ft(0.15), openingZ - ft(0.05)]}>
        <boxGeometry args={[W + ft(1.0), ft(0.25), ft(0.25)]} />
      </mesh>

      {/* Outside bright card (only when hatch open) */}
      {!hatchClosed && (
        <mesh material={outsideMat} position={[0, H - ft(0.4), openingZ - ft(2.0)]}>
          <planeGeometry args={[W + ft(12), H + ft(12)]} />
        </mesh>
      )}

      {/* Bottom landing platform */}
      <mesh material={darkSteel} position={[0, ft(0.12), landingZ + ft(0.25)]}>
        <boxGeometry args={[W - ft(1.0), ft(0.18), ft(3.2)]} />
      </mesh>

      {/* Stairs */}
      <group>
        {Array.from({ length: stepCount }).map((_, i) => {
          const y = stairStartY + i * stepRise;
          const z = stairStartZ - i * stepRun;
          return (
            <mesh key={i} material={darkSteel} position={[0, y, z]}>
              <boxGeometry args={[W - ft(1.05), ft(0.18), stepRun * 0.95]} />
            </mesh>
          );
        })}
      </group>
{/* Ceiling LED lamp (flush mount) */}
      <group position={[0, ledY, ft(0.2)]}>
        {/* Lamp base */}
        <mesh material={darkSteel} position={[0, 0, 0]}>
          <cylinderGeometry args={[ft(0.55), ft(0.55), ft(0.06), 40]} />
        </mesh>
        {/* Diffuser (emissive) */}
        <mesh material={ledMat} position={[0, -ft(0.04), 0]}>
          <cylinderGeometry args={[ft(0.50), ft(0.50), ft(0.04), 40]} />
        </mesh>
      </group>

      {/* Hatch doors */}
      {!hatchClosed ? (
        <group position={[0, hatchY, openingZ - ft(0.2)]}>
          <group position={[-(hatchW / 2 + ft(0.6)), ft(0.2), -ft(0.8)]} rotation={[0.0, 0.75, -0.12]}>
            <mesh material={steel}>
              <boxGeometry args={[hatchW, hatchT, hatchH]} />
            </mesh>
            {Array.from({ length: 3 }).map((_, i) => (
              <mesh
                key={`leafL-${i}`}
                material={darkSteel}
                position={[0, -hatchH / 2 + (i + 1) * (hatchH / 4), hatchT / 2 + ft(0.03)]}
              >
                <boxGeometry args={[hatchW * 0.88, ft(0.06), ft(0.06)]} />
              </mesh>
            ))}
          </group>

          <group position={[hatchW / 2 + ft(0.6), ft(0.2), -ft(0.8)]} rotation={[0.0, -0.75, 0.12]}>
            <mesh material={steel}>
              <boxGeometry args={[hatchW, hatchT, hatchH]} />
            </mesh>
            {Array.from({ length: 3 }).map((_, i) => (
              <mesh
                key={`leafR-${i}`}
                material={darkSteel}
                position={[0, -hatchH / 2 + (i + 1) * (hatchH / 4), hatchT / 2 + ft(0.03)]}
              >
                <boxGeometry args={[hatchW * 0.88, ft(0.06), ft(0.06)]} />
              </mesh>
            ))}
          </group>
        </group>
      ) : (
        // Closed: detailed hatch panel (light gray steel, ribs, hinge knuckles, locking bars)
        <group position={[0, hatchY, openingZ - ft(0.05)]}>
          {/* Main panel */}
          <mesh material={steel}>
            <boxGeometry args={[hatchW, hatchH, hatchT]} />
          </mesh>

          {/* Reinforcing ribs (inside face) */}
          {Array.from({ length: 4 }).map((_, i) => (
            <mesh
              key={`ribH-${i}`}
              material={darkSteel}
              position={[0, -hatchH / 2 + (i + 1) * (hatchH / 5), hatchT / 2 + ft(0.03)]}
            >
              <boxGeometry args={[hatchW * 0.92, ft(0.06), ft(0.06)]} />
            </mesh>
          ))}
          {Array.from({ length: 3 }).map((_, i) => (
            <mesh
              key={`ribV-${i}`}
              material={darkSteel}
              position={[-hatchW / 2 + (i + 1) * (hatchW / 4), 0, hatchT / 2 + ft(0.03)]}
            >
              <boxGeometry args={[ft(0.06), hatchH * 0.92, ft(0.06)]} />
            </mesh>
          ))}

          {/* Hinge knuckles (left side) */}
          {Array.from({ length: 3 }).map((_, i) => (
            <mesh
              key={`hinge-${i}`}
              material={darkSteel}
              position={[-hatchW / 2 - ft(0.04), -hatchH / 2 + (i + 1) * (hatchH / 4), 0]}
              rotation={[0, 0, Math.PI / 2]}
            >
              <cylinderGeometry args={[ft(0.04), ft(0.04), ft(0.14), 18]} />
            </mesh>
          ))}

          {/* Locking bars (right side) */}
          <mesh material={darkSteel} position={[hatchW / 2 - ft(0.10), 0, hatchT / 2 + ft(0.05)]}>
            <boxGeometry args={[ft(0.06), hatchH * 0.78, ft(0.04)]} />
          </mesh>
          <mesh material={darkSteel} position={[hatchW / 2 - ft(0.22), 0, hatchT / 2 + ft(0.05)]}>
            <boxGeometry args={[ft(0.06), hatchH * 0.78, ft(0.04)]} />
          </mesh>
        </group>
      )}

      {/* Man at bottom landing, facing hatch (-Z) — scaled so head is ~2 inches below ceiling */}
      <group
        position={[0, 0, landingZ + ft(0.10) + ft(MAN_BACK_FT)]} // stepped back further (~arm+ clearance)
        rotation={[0, Math.PI, 0]}
        scale={((H - inch(2)) / 2.02)}  // 2.02m is approx original man top height
      >
        <Man />
      </group>
    </group>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Controls (pointer + pinch) + smooth flight
// Allow +/- 180° from start => 360° range (so you can look behind you).
// ─────────────────────────────────────────────────────────────────────────────

function ControlsAndFlight({ pose, orbitYawRangeRad = Math.PI * 2, target = [0, ft(3.5), ft(1.5)], apiRef }) {
  const { camera, gl } = useThree();

  const targetRef = useRef(new THREE.Vector3(target[0], target[1], target[2]));
  const sphericalRef = useRef(new THREE.Spherical(3.6, 1.2, 0.0));
  const desiredRef = useRef(new THREE.Spherical(3.6, 1.2, 0.0));
  const baseThetaRef = useRef(null);

  const pointersRef = useRef(new Map());
  const lastSingleRef = useRef({ x: 0, y: 0 });
  const pinchRef = useRef({ active: false, dist: 0, baseRadius: 0 });

  const tweenRef = useRef(null);

  useEffect(() => {
    const s = getSphericalFromCamera(camera.position, targetRef.current);
    sphericalRef.current.copy(s);
    desiredRef.current.copy(s);
    if (baseThetaRef.current == null) baseThetaRef.current = s.theta;
  }, [camera]);

  useEffect(() => {
    if (!pose) return;
    tweenRef.current = {
      t: 0,
      duration: 0.9,
      fromCam: camera.position.clone(),
      fromTgt: targetRef.current.clone(),
      toCam: new THREE.Vector3(pose.camPos[0], pose.camPos[1], pose.camPos[2]),
      toTgt: new THREE.Vector3(pose.lookAt[0], pose.lookAt[1], pose.lookAt[2]),
    };
  }, [pose, camera]);

  useEffect(() => {
    const el = gl.domElement;
    if (!el) return;

    const ROTATE_SPEED = 0.004;
    const MIN_DIST = 0.9;
    const MAX_DIST = 18;

    const getTwo = () => {
      const vals = Array.from(pointersRef.current.values());
      if (vals.length < 2) return null;
      return [vals[0], vals[1]];
    };

    const dist2 = (a, b) => {
      const dx = a.x - b.x;
      const dy = a.y - b.y;
      return Math.sqrt(dx * dx + dy * dy);
    };

    function interruptFlight() {
      tweenRef.current = null;
      const s = getSphericalFromCamera(camera.position, targetRef.current);
      sphericalRef.current.copy(s);
      desiredRef.current.copy(s);
      if (baseThetaRef.current == null) baseThetaRef.current = s.theta;
    }

    function clampYaw() {
      const base = baseThetaRef.current ?? desiredRef.current.theta;
      const half = orbitYawRangeRad / 2;
      desiredRef.current.theta = THREE.MathUtils.clamp(desiredRef.current.theta, base - half, base + half);
    }

    function onPointerDown(e) {
      pointersRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
      lastSingleRef.current = { x: e.clientX, y: e.clientY };
      try {
        el.setPointerCapture?.(e.pointerId);
      } catch {}
      if (pointersRef.current.size >= 2) {
        const two = getTwo();
        if (two) pinchRef.current = { active: true, dist: dist2(two[0], two[1]), baseRadius: desiredRef.current.radius };
      } else {
        pinchRef.current.active = false;
      }
      interruptFlight();
    }

    function onPointerMove(e) {
      if (!pointersRef.current.has(e.pointerId)) return;
      pointersRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

      // Pinch
      if (pointersRef.current.size >= 2) {
        const two = getTwo();
        if (!two) return;
        if (!pinchRef.current.active) {
          pinchRef.current = { active: true, dist: dist2(two[0], two[1]), baseRadius: desiredRef.current.radius };
        }
        const newDist = dist2(two[0], two[1]);
        const ratio = pinchRef.current.dist > 0 ? pinchRef.current.dist / newDist : 1;
        desiredRef.current.radius = THREE.MathUtils.clamp(pinchRef.current.baseRadius * ratio, MIN_DIST, MAX_DIST);
        return;
      }

      const dx = e.clientX - lastSingleRef.current.x;
      const dy = e.clientY - lastSingleRef.current.y;
      lastSingleRef.current = { x: e.clientX, y: e.clientY };

      desiredRef.current.theta -= dx * ROTATE_SPEED;
      desiredRef.current.phi -= dy * ROTATE_SPEED;
      desiredRef.current.phi = THREE.MathUtils.clamp(desiredRef.current.phi, 0.25, Math.PI - 0.25);
      clampYaw();
    }

    function onPointerUp(e) {
      pointersRef.current.delete(e.pointerId);
      try {
        el.releasePointerCapture?.(e.pointerId);
      } catch {}
      if (pointersRef.current.size < 2) pinchRef.current.active = false;
    }

    function onWheel(e) {
      e.preventDefault();
      interruptFlight();
      desiredRef.current.radius = THREE.MathUtils.clamp(desiredRef.current.radius * (1 + e.deltaY * 0.001), MIN_DIST, MAX_DIST);
    }

    el.addEventListener("pointerdown", onPointerDown, { passive: true });
    el.addEventListener("pointermove", onPointerMove, { passive: true });
    window.addEventListener("pointerup", onPointerUp, { passive: true });
    el.addEventListener("wheel", onWheel, { passive: false });

    return () => {
      el.removeEventListener("pointerdown", onPointerDown);
      el.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerup", onPointerUp);
      el.removeEventListener("wheel", onWheel);
    };
  }, [gl, camera, orbitYawRangeRad]);


  // Expose small control API for UI buttons (left/right)
  useEffect(() => {
    if (!apiRef) return;
    apiRef.current = {
      nudgeYaw: (deltaTheta) => {
        tweenRef.current = null; // interrupt flight
        desiredRef.current.theta += deltaTheta;
        // clamp around base
        const base = baseThetaRef.current ?? desiredRef.current.theta;
        const half = orbitYawRangeRad / 2;
        desiredRef.current.theta = THREE.MathUtils.clamp(desiredRef.current.theta, base - half, base + half);
      },
      nudgeZoom: (factor) => {
        tweenRef.current = null;
        desiredRef.current.radius = THREE.MathUtils.clamp(desiredRef.current.radius * factor, 0.9, 18);
      },
    };
    return () => {
      if (apiRef) apiRef.current = null;
    };
  }, [apiRef, orbitYawRangeRad]);

  useFrame((_, delta) => {
    const tw = tweenRef.current;
    if (tw) {
      tw.t += delta;
      const k = smoothstep01(tw.t / tw.duration);
      camera.position.lerpVectors(tw.fromCam, tw.toCam, k);
      targetRef.current.lerpVectors(tw.fromTgt, tw.toTgt, k);
      camera.lookAt(targetRef.current);
      if (k >= 1) {
        tweenRef.current = null;
        const s = getSphericalFromCamera(camera.position, targetRef.current);
        sphericalRef.current.copy(s);
        desiredRef.current.copy(s);
        if (baseThetaRef.current == null) baseThetaRef.current = s.theta;
      }
      return;
    }

    const s = sphericalRef.current;
    const d = desiredRef.current;
    const damp = 1 - Math.pow(0.001, delta);

    s.radius = THREE.MathUtils.lerp(s.radius, d.radius, damp);
    s.theta = THREE.MathUtils.lerp(s.theta, d.theta, damp);
    s.phi = THREE.MathUtils.lerp(s.phi, d.phi, damp);

    camera.position.copy(cameraFromSpherical(targetRef.current, s));
    camera.lookAt(targetRef.current);
  });

  return null;
}

// ─────────────────────────────────────────────────────────────────────────────
// Scene (lighting tuned so nothing becomes black)
// ─────────────────────────────────────────────────────────────────────────────

function Scene({ setPose, hatchClosed, ghostWalls }) {
  // derive key door coordinates from DIM_FT so hotspots stay attached to geometry
  const W = ft(DIM_FT.width);
  const L = ft(DIM_FT.length);
  const H = ft(DIM_FT.height);
  const openingZ = -L / 2;
  const hatchY = H - ft(0.25);

  // Readable baseline light
  const ambient = 0.95;
  const hemi = 0.9;

  return (
    <>
      <color attach="background" args={["#151515"]} />

      <ambientLight intensity={ambient} />
      <hemisphereLight intensity={hemi} />

      {/* Ceiling lamp light: always on */}
      <pointLight position={[0, ft(6.15), ft(0.2)]} intensity={9.5} distance={40} />
      <pointLight position={[0, ft(5.6), ft(0.2)]} intensity={3.5} distance={22} />

      {/* Hatch daylight (only when open) */}
      {!hatchClosed && (
        <spotLight position={[0, ft(9.0), -ft(9.0)]} angle={0.8} penumbra={0.75} intensity={10} distance={50} />
      )}

      <Suspense fallback={null}>
        <SimpleShelter hatchClosed={hatchClosed} ghostWalls={ghostWalls} />
      </Suspense>

      {/* Hotspots */}
      <Hotspot
        position={[0, hatchY, openingZ]}
        label="Door / Hatch"
        onClick={() => setPose({ camPos: [0, hatchY - ft(0.6), openingZ + ft(3.0)], lookAt: [0, hatchY, openingZ] })}
      />
      <Hotspot
        position={[0, ft(3.2), -ft(0.8)]}
        label="Stairs"
        onClick={() => setPose({ camPos: [-ft(4.0), ft(3.2), ft(1.5)], lookAt: [0, ft(3.2), -ft(0.8)] })}
      />
      <Hotspot
        position={[0, ft(3.0), ft(3.0)]}
        label="Back wall"
        onClick={() => setPose({ camPos: [0, ft(3.0), ft(6.5)], lookAt: [0, ft(3.0), ft(3.0)] })}
      />
    </>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Self-tests
// ─────────────────────────────────────────────────────────────────────────────

function runSelfTests() {
  try {
    console.assert(smoothstep01(0) === 0, "smoothstep01(0) = 0");
    console.assert(smoothstep01(1) === 1, "smoothstep01(1) = 1");
    const tgt = new THREE.Vector3(0, 1, 0);
    const cam = new THREE.Vector3(2.2, 1.4, 3.0);
    const s = getSphericalFromCamera(cam, tgt);
    const cam2 = cameraFromSpherical(tgt, s);
    console.assert(cam.distanceTo(cam2) < 1e-6, "Spherical round-trip");
  } catch {}
}

// ─────────────────────────────────────────────────────────────────────────────
// App
// ─────────────────────────────────────────────────────────────────────────────

export default function App() {
  const [pose, setPose] = useState(null);
  const [hatchClosed, setHatchClosed] = useState(false);
  const [ghostWalls, setGhostWalls] = useState(true); // transparent walls for overview

  const containerRef = useRef(null);
  const controlsApiRef = useRef(null);
  const holdTimerRef = useRef(null);
  const [ready, setReady] = useState(false);

  useLayoutEffect(() => {
    if (containerRef.current) setReady(true);
  }, []);

  useEffect(() => {
    return () => {
      // cleanup hold interval
      if (holdTimerRef.current) {
        window.clearInterval(holdTimerRef.current);
        holdTimerRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    runSelfTests();
    if (typeof document !== "undefined") document.body.style.cursor = "default";
  }, []);

  // Start from bottom landing looking up (photo feel)
  const startCam = [0, ft(3.2), ft(5.5)];

  const YAW_STEP = THREE.MathUtils.degToRad(12); // each tap rotates 12°
  const startHold = (dir) => {
    // dir: -1 left, +1 right
    stopHold();
    // immediate nudge
    controlsApiRef.current?.nudgeYaw(dir * YAW_STEP);
    holdTimerRef.current = window.setInterval(() => {
      controlsApiRef.current?.nudgeYaw(dir * YAW_STEP * 0.5);
    }, 45);
  };
  const stopHold = () => {
    if (holdTimerRef.current) {
      window.clearInterval(holdTimerRef.current);
      holdTimerRef.current = null;
    }
  };

  const startLook = [0, ft(4.0), -ft(1.0)];

  const wrapStyle = {
    position: "relative",
    width: "100%",
    height: "80vh",
    background: "#0b0b0b",
    borderRadius: 16,
    overflow: "hidden",
    border: "1px solid rgba(255,255,255,0.10)",
  };

  const hudStyle = {
    position: "absolute",
    zIndex: 10,
    top: 12,
    left: 12,
    right: 12,
    display: "flex",
    flexWrap: "wrap",
    gap: 8,
    alignItems: "center",
    pointerEvents: "none",
  };

  const pillStyle = {
    padding: "8px 10px",
    borderRadius: 12,
    background: "rgba(0,0,0,0.55)",
    color: "white",
    fontSize: 12,
    border: "1px solid rgba(255,255,255,0.16)",
    backdropFilter: "blur(6px)",
    pointerEvents: "all",
  };

  const btnStyle = { ...pillStyle, cursor: "pointer" };

  return (
    <div ref={containerRef} style={wrapStyle}>
      <div style={hudStyle}>
        <div style={pillStyle}>Drag/swipe to look • Scroll/pinch to zoom • You can turn around (±180°)</div>

        <div style={{ display: "flex", gap: 8, pointerEvents: "all" }}>
          <button
            style={btnStyle}
            onMouseDown={() => startHold(-1)}
            onMouseUp={stopHold}
            onMouseLeave={stopHold}
            onTouchStart={(e) => {
              e.preventDefault();
              startHold(-1);
            }}
            onTouchEnd={stopHold}
            aria-label="Turn left"
          >
            ◀ Turn
          </button>
          <button
            style={btnStyle}
            onMouseDown={() => startHold(+1)}
            onMouseUp={stopHold}
            onMouseLeave={stopHold}
            onTouchStart={(e) => {
              e.preventDefault();
              startHold(+1);
            }}
            onTouchEnd={stopHold}
            aria-label="Turn right"
          >
            Turn ▶
          </button>
        </div>

        <button style={btnStyle} onClick={() => setPose({ camPos: startCam, lookAt: startLook })}>
          Reset
        </button>
        <button style={btnStyle} onClick={() => setPose({ camPos: [0, ft(5.2), -ft(1.0)], lookAt: [0, ft(6.0), -ft(4.0)] })}>
          Hatch
        </button>
        <button style={btnStyle} onClick={() => setPose({ camPos: [-ft(4.0), ft(3.2), ft(1.5)], lookAt: [0, ft(3.2), -ft(0.8)] })}>
          Stairs
        </button>
        <button style={btnStyle} onClick={() => setPose({ camPos: [0, ft(3.0), ft(6.5)], lookAt: [0, ft(3.0), ft(3.0)] })}>
          Back
        </button>

        <button style={btnStyle} onClick={() => setHatchClosed((v) => !v)}>
          {hatchClosed ? "Open Hatch" : "Close Hatch"}
        </button>
        <button style={btnStyle} onClick={() => setGhostWalls((v) => !v)}>
          {ghostWalls ? "Walls: Transparent" : "Walls: Solid"}
        </button>
      </div>

      {ready && containerRef.current && (
        <Canvas
          camera={{ position: startCam, fov: 62, near: 0.05, far: 200 }}
          gl={{ antialias: true }}
          eventSource={containerRef.current}
          eventPrefix="client"
          onCreated={({ gl }) => {
            // Brighten overall exposure to avoid “everything black”
            gl.toneMapping = THREE.ACESFilmicToneMapping;
            gl.toneMappingExposure = 1.35;
            if ("outputColorSpace" in gl && THREE.SRGBColorSpace) gl.outputColorSpace = THREE.SRGBColorSpace;
            if ("outputEncoding" in gl && THREE.sRGBEncoding) gl.outputEncoding = THREE.sRGBEncoding;
          }}
        >
          {/* Target around stairwell center; yaw range = 360° (turn around) */}
          <ControlsAndFlight pose={pose} orbitYawRangeRad={Math.PI * 2} target={[0, ft(4.0), ft(1.0)]} apiRef={controlsApiRef} />
          <Scene setPose={setPose} hatchClosed={hatchClosed} ghostWalls={ghostWalls} />
        </Canvas>
      )}
    </div>
  );
}
