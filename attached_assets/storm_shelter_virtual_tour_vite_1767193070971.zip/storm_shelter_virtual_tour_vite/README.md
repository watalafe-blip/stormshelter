Storm Shelter Virtual Tour (Vite + React Three Fiber)

Run locally:
  npm install
  npm run dev

Build:
  npm run build
  npm run preview

If you want to use a real .glb model later:
- Add @react-three/drei and use useGLTF, or use Three.js GLTFLoader directly.
