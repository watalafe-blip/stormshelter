import React, { Suspense, useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { Canvas, useFrame, useThree } from "@react-three/fiber";

/**
 * Embedded-friendly virtual tour (finicky preview-safe):
 * - Drag to orbit, scroll to zoom
 * - Click hotspots to smoothly fly camera to Door / Stairs / Interior
 * - Avoids @react-three/drei (Html/OrbitControls can crash with "reading 'source'")
 * - Avoids three/examples OrbitControls + extend() (can fail in some sandboxes)
 * - No external assets (HDRIs, environments, network fetches)
 */

// ------------------------
// Utilities
// ------------------------

function clamp01(x) {
  return Math.max(0, Math.min(1, x));
}

function smoothstep01(t) {
  const x = clamp01(t);
  return x * x * (3 - 2 * x);
}

function roundRect(ctx, x, y, width, height, radius) {
  const r = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + width, y, x + width, y + height, r);
  ctx.arcTo(x + width, y + height, x, y + height, r);
  ctx.arcTo(x, y + height, x, y, r);
  ctx.arcTo(x, y, x + width, y, r);
  ctx.closePath();
}

function getSphericalFromCamera(cameraPos, target) {
  const v = new THREE.Vector3().subVectors(cameraPos, target);
  const spherical = new THREE.Spherical();
  spherical.setFromVector3(v);
  // clamp phi to avoid flips
  spherical.phi = THREE.MathUtils.clamp(spherical.phi, 0.001, Math.PI - 0.001);
  return spherical;
}

function cameraFromSpherical(target, spherical) {
  const v = new THREE.Vector3().setFromSpherical(spherical);
  return new THREE.Vector3().addVectors(target, v);
}

// ------------------------
// Label Sprite (CanvasTexture)
// ------------------------

function createLabelTexture(text) {
  try {
    if (typeof document === "undefined") return null;

    const paddingX = 18;
    const paddingY = 10;
    const fontSize = 22;
    const fontFamily = "system-ui, -apple-system, Segoe UI, Roboto, Arial";

    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    if (!ctx) return null;

    ctx.font = `600 ${fontSize}px ${fontFamily}`;
    const metrics = ctx.measureText(text);
    const textWidth = Math.ceil(metrics.width);
    const textHeight = Math.ceil(fontSize * 1.2);

    const w = textWidth + paddingX * 2;
    const h = textHeight + paddingY * 2;

    // 2x draw for sharpness
    canvas.width = w * 2;
    canvas.height = h * 2;
    ctx.scale(2, 2);

    // Background
    ctx.fillStyle = "rgba(0,0,0,0.55)";
    ctx.strokeStyle = "rgba(255,255,255,0.16)";
    ctx.lineWidth = 1;
    roundRect(ctx, 0.5, 0.5, w - 1, h - 1, 12);
    ctx.fill();
    ctx.stroke();

    // Text
    ctx.fillStyle = "#ffffff";
    ctx.textBaseline = "middle";
    ctx.font = `600 ${fontSize}px ${fontFamily}`;
    ctx.fillText(text, paddingX, h / 2);

    const texture = new THREE.CanvasTexture(canvas);
    if (!texture) return null;

    // Compatibility across Three versions
    if ("colorSpace" in texture && THREE.SRGBColorSpace) {
      texture.colorSpace = THREE.SRGBColorSpace;
    } else if ("encoding" in texture && THREE.sRGBEncoding) {
      texture.encoding = THREE.sRGBEncoding;
    }

    texture.minFilter = THREE.LinearFilter;
    texture.magFilter = THREE.LinearFilter;
    texture.needsUpdate = true;

    texture.userData = { w, h };
    return texture;
  } catch {
    return null;
  }
}

function Hotspot({ position, label, onClick }) {
  const texture = useMemo(() => createLabelTexture(label), [label]);

  const spriteScale = useMemo(() => {
    if (!texture?.userData) return [0.9, 0.28, 1];
    const { w, h } = texture.userData;
    const k = 220; // normalization
    return [Math.max(0.6, w / k), Math.max(0.22, h / k), 1];
  }, [texture]);

  return (
    <group position={position}>
      <mesh
        onClick={(e) => {
          e.stopPropagation();
          onClick?.();
        }}
        onPointerOver={(e) => {
          e.stopPropagation();
          if (typeof document !== "undefined") document.body.style.cursor = "pointer";
        }}
        onPointerOut={(e) => {
          e.stopPropagation();
          if (typeof document !== "undefined") document.body.style.cursor = "default";
        }}
      >
        <sphereGeometry args={[0.06, 18, 18]} />
        <meshStandardMaterial color={"#111"} emissive={"#fff"} emissiveIntensity={1.6} roughness={0.3} />
      </mesh>

      {texture && (
        <sprite position={[0, 0.18, 0]} scale={spriteScale} renderOrder={10}>
          <spriteMaterial map={texture} transparent depthWrite={false} toneMapped={false} />
        </sprite>
      )}
    </group>
  );
}

// ------------------------
// Manual Orbit Controls + Camera Flight
// ------------------------

function ControlsAndFlight({ pose }) {
  const { camera, gl } = useThree();

  const targetRef = useRef(new THREE.Vector3(0, 1.0, 0));

  // Orbit state
  const sphericalRef = useRef(new THREE.Spherical(3.9, 1.2, 0.7));
  const desiredRef = useRef(new THREE.Spherical(3.9, 1.2, 0.7));

  const draggingRef = useRef(false);
  const lastRef = useRef({ x: 0, y: 0 });

  // Flight tween
  const tweenRef = useRef(null);

  // Init camera and spherical based on initial camera position
  useEffect(() => {
    const t = targetRef.current;
    const s = getSphericalFromCamera(camera.position, t);
    sphericalRef.current.copy(s);
    desiredRef.current.copy(s);
  }, [camera]);

  // Pose changes trigger a flight (smooth camera move)
  useEffect(() => {
    if (!pose) return;

    const fromCam = camera.position.clone();
    const fromTgt = targetRef.current.clone();

    const toCam = new THREE.Vector3(pose.camPos[0], pose.camPos[1], pose.camPos[2]);
    const toTgt = new THREE.Vector3(pose.lookAt[0], pose.lookAt[1], pose.lookAt[2]);

    tweenRef.current = {
      t: 0,
      duration: 0.85,
      fromCam,
      fromTgt,
      toCam,
      toTgt,
    };
  }, [pose, camera]);

  // DOM events for orbit/zoom (avoid r3f event "source" issues)
  useEffect(() => {
    const el = gl.domElement;
    if (!el) return;

    const ROTATE_SPEED = 0.004;
    const ZOOM_SPEED = 0.001;
    const MIN_DIST = 0.8;
    const MAX_DIST = 12;

    function onPointerDown(e) {
      draggingRef.current = true;
      lastRef.current = { x: e.clientX, y: e.clientY };
      try {
        el.setPointerCapture?.(e.pointerId);
      } catch {}
    }

    function onPointerMove(e) {
      if (!draggingRef.current) return;

      const dx = e.clientX - lastRef.current.x;
      const dy = e.clientY - lastRef.current.y;
      lastRef.current = { x: e.clientX, y: e.clientY };

      // While flying, let the flight finish (prevents fighting)
      if (tweenRef.current) return;

      const d = desiredRef.current;
      d.theta -= dx * ROTATE_SPEED;
      d.phi -= dy * ROTATE_SPEED;
      d.phi = THREE.MathUtils.clamp(d.phi, 0.001, Math.PI - 0.001);
    }

    function onPointerUp(e) {
      draggingRef.current = false;
      try {
        el.releasePointerCapture?.(e.pointerId);
      } catch {}
    }

    function onWheel(e) {
      // prevent page scroll in embedded preview
      e.preventDefault();

      if (tweenRef.current) return;

      const d = desiredRef.current;
      d.radius *= 1 + e.deltaY * ZOOM_SPEED;
      d.radius = THREE.MathUtils.clamp(d.radius, MIN_DIST, MAX_DIST);
    }

    el.addEventListener("pointerdown", onPointerDown, { passive: true });
    window.addEventListener("pointermove", onPointerMove, { passive: true });
    window.addEventListener("pointerup", onPointerUp, { passive: true });
    el.addEventListener("wheel", onWheel, { passive: false });

    return () => {
      el.removeEventListener("pointerdown", onPointerDown);
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerup", onPointerUp);
      el.removeEventListener("wheel", onWheel);
    };
  }, [gl, camera]);

  useFrame((_, delta) => {
    // Flight tween
    const tw = tweenRef.current;
    if (tw) {
      tw.t += delta;
      const k = smoothstep01(tw.t / tw.duration);

      camera.position.lerpVectors(tw.fromCam, tw.toCam, k);
      targetRef.current.lerpVectors(tw.fromTgt, tw.toTgt, k);
      camera.lookAt(targetRef.current);

      if (k >= 1) {
        tweenRef.current = null;
        // Sync orbit state to end of flight
        const s = getSphericalFromCamera(camera.position, targetRef.current);
        sphericalRef.current.copy(s);
        desiredRef.current.copy(s);
      }
      return;
    }

    // Orbit damping
    const s = sphericalRef.current;
    const d = desiredRef.current;

    // A simple exponential smoothing
    const damp = 1 - Math.pow(0.001, delta);
    s.radius = THREE.MathUtils.lerp(s.radius, d.radius, damp);
    s.theta = THREE.MathUtils.lerp(s.theta, d.theta, damp);
    s.phi = THREE.MathUtils.lerp(s.phi, d.phi, damp);

    const nextCam = cameraFromSpherical(targetRef.current, s);
    camera.position.copy(nextCam);
    camera.lookAt(targetRef.current);
  });

  return null;
}

// ------------------------
// Simple Shelter (fallback geometry)
// ------------------------

function Man() {
  return (
    <group position={[0.0, 0, 0.9]} rotation={[0, Math.PI, 0]}>
      <mesh position={[0, 0.95, 0]}>
        <cylinderGeometry args={[0.22, 0.24, 1.35, 18]} />
        <meshStandardMaterial color={"#1f3f66"} roughness={0.85} />
      </mesh>
      <mesh position={[0, 1.75, 0]}>
        <sphereGeometry args={[0.16, 18, 18]} />
        <meshStandardMaterial color={"#cfa37b"} roughness={0.9} />
      </mesh>
    </group>
  );
}

function SimpleShelter() {
  const wallMat = useMemo(
    () => new THREE.MeshStandardMaterial({ color: "#cfcfcf", roughness: 0.9, metalness: 0.0 }),
    []
  );
  const steelMat = useMemo(
    () => new THREE.MeshStandardMaterial({ color: "#444", roughness: 0.35, metalness: 0.85 }),
    []
  );

  return (
    <group>
      {/* Outer shell */}
      <mesh material={wallMat} position={[0, 1, 0]}>
        <boxGeometry args={[3.2, 2.2, 4.2]} />
      </mesh>

      {/* Inner "void" */}
      <mesh position={[0, 1, 0]}>
        <boxGeometry args={[3.05, 2.05, 4.05]} />
        <meshStandardMaterial color={"#ffffff"} roughness={1} transparent opacity={0.92} />
      </mesh>

      {/* Floor */}
      <mesh material={wallMat} position={[0, 0.02, 0]}>
        <boxGeometry args={[3.1, 0.05, 4.0]} />
      </mesh>

      {/* Stairs */}
      <group position={[-0.7, 0.15, -0.8]} rotation={[0, 0.15, 0]}>
        {[0, 1, 2, 3, 4].map((i) => (
          <mesh key={i} material={steelMat} position={[0, i * 0.17, i * 0.28]}>
            <boxGeometry args={[0.9, 0.06, 0.28]} />
          </mesh>
        ))}
        <mesh material={steelMat} position={[0.45, 0.55, 0.65]} rotation={[0, 0, -0.25]}>
          <cylinderGeometry args={[0.02, 0.02, 1.4, 16]} />
        </mesh>
      </group>

      {/* Door / hatch */}
      <group position={[0, 2.05, -1.5]}>
        <mesh material={steelMat} position={[-0.65, 0, 0]} rotation={[0, 0.9, 0]}>
          <boxGeometry args={[1.2, 0.08, 1.4]} />
        </mesh>
        <mesh material={steelMat} position={[0.65, 0, 0]} rotation={[0, -0.9, 0]}>
          <boxGeometry args={[1.2, 0.08, 1.4]} />
        </mesh>
      </group>

      <Man />

      {/* Ground */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]}>
        <planeGeometry args={[40, 40]} />
        <meshStandardMaterial color={"#0b0b0b"} roughness={1} />
      </mesh>
    </group>
  );
}

function Scene({ setPose }) {
  return (
    <>
      <ambientLight intensity={0.55} />
      <directionalLight position={[5, 6, 4]} intensity={1.15} />

      <Suspense fallback={null}>
        <SimpleShelter />
      </Suspense>

      {/* Hotspots */}
      <Hotspot
        position={[0.0, 2.0, -1.5]}
        label="Door / Hatch"
        onClick={() =>
          setPose({
            camPos: [0.0, 1.9, 0.2],
            lookAt: [0.0, 2.0, -1.5],
          })
        }
      />
      <Hotspot
        position={[-0.7, 0.9, -0.4]}
        label="Stairs"
        onClick={() =>
          setPose({
            camPos: [-2.2, 1.2, 1.6],
            lookAt: [-0.7, 0.9, -0.4],
          })
        }
      />
      <Hotspot
        position={[0.0, 1.0, 0.9]}
        label="Interior"
        onClick={() =>
          setPose({
            camPos: [2.2, 1.4, 2.4],
            lookAt: [0.2, 1.0, 0.2],
          })
        }
      />
    </>
  );
}

// ------------------------
// Lightweight self-tests
// ------------------------

function runSelfTests() {
  try {
    const okPose = (p) =>
      p &&
      Array.isArray(p.camPos) &&
      p.camPos.length === 3 &&
      Array.isArray(p.lookAt) &&
      p.lookAt.length === 3 &&
      p.camPos.every((n) => Number.isFinite(n)) &&
      p.lookAt.every((n) => Number.isFinite(n));

    console.assert(okPose({ camPos: [2.2, 1.4, 3.0], lookAt: [0, 1, 0] }), "Pose shape should be valid");
    console.assert(smoothstep01(0) === 0, "smoothstep01(0) === 0");
    console.assert(smoothstep01(1) === 1, "smoothstep01(1) === 1");

    // New test: spherical conversion round-trip
    const tgt = new THREE.Vector3(0, 1, 0);
    const cam = new THREE.Vector3(2.2, 1.4, 3.0);
    const s = getSphericalFromCamera(cam, tgt);
    const cam2 = cameraFromSpherical(tgt, s);
    console.assert(cam.distanceTo(cam2) < 1e-6, "Spherical conversion should round-trip");

    // Texture test (won't fail app)
    const tex = createLabelTexture("Test");
    if (typeof document === "undefined") {
      console.assert(tex === null, "Texture should be null without document");
    }
  } catch {
    // Never fail the app because of tests
  }
}

export default function App() {
  const [pose, setPose] = useState(null);

  useEffect(() => {
    runSelfTests();
    return () => {
      if (typeof document !== "undefined") document.body.style.cursor = "default";
    };
  }, []);

  const wrapStyle = {
    position: "relative",
    width: "100%",
    height: "80vh",
    background: "#0b0b0b",
    borderRadius: 16,
    overflow: "hidden",
    border: "1px solid rgba(255,255,255,0.10)",
  };

  const hudStyle = {
    position: "absolute",
    zIndex: 10,
    top: 12,
    left: 12,
    right: 12,
    display: "flex",
    flexWrap: "wrap",
    gap: 8,
    alignItems: "center",
  };

  const pillStyle = {
    padding: "8px 10px",
    borderRadius: 12,
    background: "rgba(0,0,0,0.55)",
    color: "white",
    fontSize: 12,
    border: "1px solid rgba(255,255,255,0.16)",
    backdropFilter: "blur(6px)",
  };

  const btnStyle = {
    ...pillStyle,
    cursor: "pointer",
  };

  return (
    <div style={wrapStyle}>
      <div style={hudStyle}>
        <div style={pillStyle}>Drag to look • Scroll to zoom • Click hotspots</div>
        <button style={btnStyle} onClick={() => setPose({ camPos: [2.2, 1.4, 3.0], lookAt: [0, 1.0, 0] })}>
          Reset
        </button>
        <button style={btnStyle} onClick={() => setPose({ camPos: [0.0, 1.9, 0.2], lookAt: [0.0, 2.0, -1.5] })}>
          Door
        </button>
        <button style={btnStyle} onClick={() => setPose({ camPos: [-2.2, 1.2, 1.6], lookAt: [-0.7, 0.9, -0.4] })}>
          Stairs
        </button>
        <button style={btnStyle} onClick={() => setPose({ camPos: [2.2, 1.4, 2.4], lookAt: [0.2, 1.0, 0.2] })}>
          Interior
        </button>
      </div>

      <Canvas camera={{ position: [2.2, 1.4, 3.0], fov: 52 }} gl={{ antialias: true }}>
        <ControlsAndFlight pose={pose} />
        <Scene setPose={setPose} />
      </Canvas>
    </div>
  );
}
